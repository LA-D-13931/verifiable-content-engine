# 引擎封包 v0.81.20261012+ddf9a3b

- 引擎 revision：`ddf9a3b`
- 打包时间：2026-10-12 19:13:09
- 事实源四数：`{"checks": 28, "engine_lines": 5287, "tool_lines": 9100, "tool_scripts": 53}`

## 解包后怎么验（**两条命令，退出码即结论** ✓）

```bash
cd apps/linalg-lab && python3 tools/verify-all.py --all
cd engine-core/adapters/content-spec && python3 runner.py --selftest --scope repo
cd engine-core/adapters/content-spec && python3 runner.py --selftest --scope env
```

退出码 ✓：`0` 通过 ｜ `1` 失败 ｜ `2` **没验成**（环境不足，不是通过 ✗）｜ `3` 检查器崩溃 ✓
